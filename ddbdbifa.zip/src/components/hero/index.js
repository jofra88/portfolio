import { React} from "react";
const Hero=() => {
    return <div>
        Hero123
    </div>;
};
export default Hero;